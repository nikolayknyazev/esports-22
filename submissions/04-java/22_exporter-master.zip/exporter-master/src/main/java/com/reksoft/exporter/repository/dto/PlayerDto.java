package com.reksoft.exporter.repository.dto;

import lombok.Data;

@Data
public class PlayerDto {
    private Integer id;
    private String combinedName;
    private String name;
    private String surname;
    private String nickName;
    private String country;
    private String teamName;
}
