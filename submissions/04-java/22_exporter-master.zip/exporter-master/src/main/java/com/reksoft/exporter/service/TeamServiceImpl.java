package com.reksoft.exporter.service;

import com.reksoft.exporter.model.Team;
import com.reksoft.exporter.repository.TeamApiRepository;
import com.reksoft.exporter.repository.dto.TeamDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class TeamServiceImpl implements TeamService {

    private final TeamApiRepository teamApiRepository;

    @Override
    public List<Team> getTeams() {
        List<TeamDto> TeamDtos = teamApiRepository.getTeams();
        return TeamDtos.stream().map(this::map).toList();
    }

    private Team map(TeamDto TeamDto) {
        Team team = new Team();
        team.setId(TeamDto.getId());
        team.setName(TeamDto.getName());
        team.setPlayers(TeamDto.getPlayers());
        return team;
    }
}
