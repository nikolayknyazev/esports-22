package com.reksoft.exporter.repository;

import com.reksoft.exporter.properties.ApiProperties;
import com.reksoft.exporter.repository.dto.PlayerDto;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.springframework.http.HttpMethod.GET;

@Repository
@RequiredArgsConstructor
public class PlayerApiRepository implements PlayerRepository {

    private final RestTemplate restTemplate;
    private final ApiProperties apiProperties;

    public List<PlayerDto> getPlayers() {
        ResponseEntity<List<PlayerDto>> response = restTemplate.exchange(
                apiProperties.getBaseUrl() + "/api/Players",
                GET,
                null,
                new ParameterizedTypeReference<>() {
                }
        );
        return response.getBody();
    }

}
