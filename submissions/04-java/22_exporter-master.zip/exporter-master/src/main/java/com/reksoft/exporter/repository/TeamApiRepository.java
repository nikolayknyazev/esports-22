package com.reksoft.exporter.repository;

import com.reksoft.exporter.properties.ApiProperties;
import com.reksoft.exporter.repository.dto.TeamDto;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

import static org.springframework.http.HttpMethod.GET;

@Repository
@RequiredArgsConstructor
public class TeamApiRepository implements TeamRepository {

    private final RestTemplate restTemplate;
    private final ApiProperties apiProperties;

    public List<TeamDto> getTeams() {
        ResponseEntity<List<TeamDto>> response = restTemplate.exchange(
                apiProperties.getBaseUrl() + "/api/Teams",
                GET,
                null,
                new ParameterizedTypeReference<>() {
                }
        );
        return response.getBody();
    }

    public List<TeamDto> getTeamById(String teamId) {
        String uri = UriComponentsBuilder.fromHttpUrl(apiProperties.getBaseUrl() + "/api/Teams")
                .path("/{id}")
                .buildAndExpand(teamId)
                .toUriString();

        ResponseEntity<List<TeamDto>> response = restTemplate.exchange(
                uri,
                GET,
                null,
                new ParameterizedTypeReference<>() {
                }
        );
        return response.getBody();
    }

    public List<TeamDto> getIncomeTeamByIdAndYear(String teamId, String year) {
        ResponseEntity<List<TeamDto>> response = restTemplate.exchange(
                apiProperties.getBaseUrl() + "/api/Teams/{teamId}/{year}/income",
                GET,
                null,
                new ParameterizedTypeReference<>() {
                },
                teamId,
                year
        );
        return response.getBody();
    }

}
