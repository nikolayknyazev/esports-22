package com.reksoft.exporter.repository;

import com.reksoft.exporter.repository.dto.PlayerDto;

import java.util.List;

public interface PlayerRepository {

    List<PlayerDto> getPlayers();
}
