package com.reksoft.exporter.repository;

import com.reksoft.exporter.model.Player;

import java.util.List;

public interface PlayerRepository {

    List<Player> getPlayers();
}
