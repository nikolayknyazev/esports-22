package com.reksoft.exporter.service;

import com.reksoft.exporter.model.Player;
import com.reksoft.exporter.repository.PlayerApiRepository;
import com.reksoft.exporter.repository.dto.PlayerDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PlayerServiceImpl implements PlayerService {

    private final PlayerApiRepository playerApiRepository;

    @Override
    public List<Player> getPlayers() {
        List<PlayerDto> playerDtos = playerApiRepository.getPlayers();
        return playerDtos.stream().map(this::map).toList();
    }

    private Player map(PlayerDto playerDto) {
        Player player = new Player();
        player.setId(playerDto.getId());
        player.setCombinedName(playerDto.getCombinedName());
        player.setNickName(playerDto.getNickName());
        player.setCountry(playerDto.getCountry());
        player.setTeamName(playerDto.getTeamName());
        player.setFullName("%s \"%s\" %s".formatted(
                playerDto.getName(),
                playerDto.getNickName(),
                playerDto.getSurname()
        ));
        return player;
    }
}
