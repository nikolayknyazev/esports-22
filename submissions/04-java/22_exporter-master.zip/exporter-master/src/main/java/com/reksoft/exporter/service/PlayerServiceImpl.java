package com.reksoft.exporter.service;

import com.reksoft.exporter.model.Player;
import com.reksoft.exporter.repository.PlayerApiRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PlayerServiceImpl implements PlayerService {

    private final PlayerApiRepository playerApiRepository;

    @Override
    public List<Player> getPlayers() {
        List<Player> players = playerApiRepository.getPlayers();
        return players.stream().map(this::map).toList();
    }

    private Player map(Player players) {
        Player player = new Player();
        player.setId(players.getId());
        player.setCombinedName(players.getCombinedName());
        player.setNickName(players.getNickName());
        player.setCountry(players.getCountry());
        player.setTeamName(players.getTeamName());
        player.setFullName("%s \"%s\" %s".formatted(
                players.getCombinedName().split(" ")[0],
                players.getNickName(),
                players.getCombinedName().split(" ")[1]
        ));
        return player;
    }
}
